package antlr.debug;

public interface NewLineListener extends ListenerBase {


	public void hitNewLine(NewLineEvent e);
}
